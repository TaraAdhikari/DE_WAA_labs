/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hello;

/**
 *
 * @author Rajen
 */
public class Hello
{
    private String userName;
    public String getUserName()
    {
    return userName;
    }
    public void setUserName(String userName)
    {
    this.userName = userName;
    }
    public String sayHello()
    {
    return "";
    }
}
